import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import Login from './pages/Auth/Login';
import Register from './pages/Auth/Register';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import Dashboard from './pages/Dashboard';
import RecipesList from './pages/Recipes/RecipesList';
import CreateRecipe from './pages/Recipes/CreateRecipe';
import RecipeDetail from './pages/Recipes/RecipeDetail';
import Ingredients from './pages/Ingredients';
import Suppliers from './pages/Suppliers';
import Products from './pages/Products';

function FullScreenLoader() {
  return (
    <div className="h-screen flex items-center justify-center text-ink-300">
      Carregando…
    </div>
  );
}

export default function App() {
  const { loading } = useAuth();
  if (loading) return <FullScreenLoader />;

  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />

      <Route
        element={
          <ProtectedRoute>
            <Layout />
          </ProtectedRoute>
        }
      >
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/recipes" element={<RecipesList />} />
        <Route path="/recipes/new" element={<CreateRecipe />} />
        <Route path="/recipes/:id" element={<RecipeDetail />} />
        <Route path="/ingredients" element={<Ingredients />} />
        <Route path="/suppliers" element={<Suppliers />} />
        <Route path="/products" element={<Products />} />
      </Route>

      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}
