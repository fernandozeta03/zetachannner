export const brl = (v) =>
  Number(v ?? 0).toLocaleString('pt-BR', {
    style: 'currency',
    currency: 'BRL',
  });

export const fmtCmv = (v) => `${Number(v ?? 0).toFixed(2)}%`;

export const cmvColor = (cmv) => {
  const v = Number(cmv);
  if (v <= 25) return 'text-emerald-400';
  if (v <= 35) return 'text-amber-400';
  return 'text-red-400';
};
