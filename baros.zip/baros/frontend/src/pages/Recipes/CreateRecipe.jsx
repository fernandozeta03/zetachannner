import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { Plus, Trash2 } from 'lucide-react';
import api from '../../api/axios';
import { brl, fmtCmv, cmvColor } from '../../utils/format';

export default function CreateRecipe() {
  const navigate = useNavigate();
  const [ingredients, setIngredients] = useState([]);
  const [form, setForm] = useState({
    name: '',
    category: 'Drink',
    glassware: '',
    garnish: '',
    preparation: '',
    salePrice: 0,
  });
  const [items, setItems] = useState([{ ingredientId: '', quantity: 0 }]);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    api.get('/ingredients').then((res) => setIngredients(res.data));
  }, []);

  const ingMap = useMemo(
    () => Object.fromEntries(ingredients.map((i) => [i.id, i])),
    [ingredients],
  );

  // Cálculo de custo e CMV em tempo real (espelha lógica do backend)
  const { totalCost, cmv } = useMemo(() => {
    let total = 0;
    items.forEach((it) => {
      const ing = ingMap[it.ingredientId];
      if (ing) total += Number(it.quantity || 0) * Number(ing.baseCost || 0);
    });
    const sale = Number(form.salePrice) || 0;
    const c = sale > 0 ? (total / sale) * 100 : 0;
    return { totalCost: total, cmv: c };
  }, [items, ingMap, form.salePrice]);

  const addItem = () =>
    setItems([...items, { ingredientId: '', quantity: 0 }]);

  const updateItem = (idx, patch) =>
    setItems(items.map((it, i) => (i === idx ? { ...it, ...patch } : it)));

  const removeItem = (idx) =>
    setItems(items.filter((_, i) => i !== idx));

  const suggestPrice = (target = 25) => {
    if (totalCost <= 0) {
      toast.error('Adicione ingredientes antes de sugerir preço');
      return;
    }
    const suggested = +(totalCost / (target / 100)).toFixed(2);
    setForm({ ...form, salePrice: suggested });
    toast.success(`Sugestão para CMV ${target}%: ${brl(suggested)}`);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const payloadItems = items.filter(
      (it) => it.ingredientId && Number(it.quantity) > 0,
    );
    if (payloadItems.length === 0) {
      toast.error('Adicione ao menos 1 ingrediente válido');
      return;
    }
    setSaving(true);
    try {
      const { data } = await api.post('/recipes', {
        ...form,
        salePrice: Number(form.salePrice),
        ingredients: payloadItems.map((it) => ({
          ingredientId: it.ingredientId,
          quantity: Number(it.quantity),
        })),
      });
      toast.success('Receita criada!');
      navigate(`/recipes/${data.id}`);
    } catch (err) {
      toast.error(err.response?.data?.message || 'Erro ao salvar');
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="text-2xl font-semibold">Nova Receita</h1>
        <p className="text-sm text-ink-400">
          Cadastre a ficha técnica completa do drink
        </p>
      </div>

      <form onSubmit={handleSubmit} className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <div className="card space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="label">Nome *</label>
                <input
                  className="input"
                  value={form.name}
                  onChange={(e) => setForm({ ...form, name: e.target.value })}
                  required
                />
              </div>
              <div>
                <label className="label">Categoria</label>
                <input
                  className="input"
                  value={form.category}
                  onChange={(e) => setForm({ ...form, category: e.target.value })}
                />
              </div>
              <div>
                <label className="label">Copo (Glassware)</label>
                <input
                  className="input"
                  value={form.glassware}
                  onChange={(e) => setForm({ ...form, glassware: e.target.value })}
                  placeholder="Old Fashioned, Coupe…"
                />
              </div>
              <div>
                <label className="label">Garnish</label>
                <input
                  className="input"
                  value={form.garnish}
                  onChange={(e) => setForm({ ...form, garnish: e.target.value })}
                  placeholder="Casca de laranja…"
                />
              </div>
            </div>

            <div>
              <label className="label">Modo de preparo</label>
              <textarea
                rows={4}
                className="input"
                value={form.preparation}
                onChange={(e) => setForm({ ...form, preparation: e.target.value })}
                placeholder="Descreva o passo-a-passo…"
              />
            </div>
          </div>

          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold">Ingredientes</h3>
              <button type="button" onClick={addItem} className="btn-ghost">
                <Plus size={14} /> Adicionar
              </button>
            </div>

            <div className="space-y-2">
              {items.map((it, idx) => {
                const ing = ingMap[it.ingredientId];
                const lineCost =
                  Number(it.quantity || 0) * Number(ing?.baseCost || 0);
                return (
                  <div
                    key={idx}
                    className="grid grid-cols-12 gap-2 items-end p-3 rounded-lg bg-ink-700/50 border border-ink-700"
                  >
                    <div className="col-span-12 md:col-span-6">
                      <label className="label">Ingrediente</label>
                      <select
                        className="input"
                        value={it.ingredientId}
                        onChange={(e) =>
                          updateItem(idx, { ingredientId: e.target.value })
                        }
                      >
                        <option value="">— Selecione —</option>
                        {ingredients.map((i) => (
                          <option key={i.id} value={i.id}>
                            {i.name} ({i.unit}) · {brl(i.baseCost)}/{i.unit}
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="col-span-5 md:col-span-3">
                      <label className="label">Qtd. {ing ? `(${ing.unit})` : ''}</label>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        className="input"
                        value={it.quantity}
                        onChange={(e) =>
                          updateItem(idx, { quantity: e.target.value })
                        }
                      />
                    </div>
                    <div className="col-span-5 md:col-span-2">
                      <label className="label">Custo</label>
                      <p className="input bg-ink-800/50 text-ink-300">
                        {brl(lineCost)}
                      </p>
                    </div>
                    <div className="col-span-2 md:col-span-1">
                      <button
                        type="button"
                        onClick={() => removeItem(idx)}
                        className="btn-ghost w-full text-red-400"
                        title="Remover"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {ingredients.length === 0 && (
              <p className="mt-4 text-sm text-amber-400">
                Você precisa cadastrar ingredientes primeiro em <strong>Ingredientes</strong>.
              </p>
            )}
          </div>
        </div>

        {/* Painel lateral: cálculos */}
        <div className="space-y-4">
          <div className="card">
            <h3 className="font-semibold mb-4">Resumo financeiro</h3>
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-ink-400">Custo total</span>
                <span className="font-semibold">{brl(totalCost)}</span>
              </div>
              <div>
                <label className="label">Preço de venda (R$)</label>
                <input
                  type="number"
                  step="0.01"
                  min="0"
                  className="input"
                  value={form.salePrice}
                  onChange={(e) =>
                    setForm({ ...form, salePrice: e.target.value })
                  }
                />
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-ink-400">CMV</span>
                <span className={`font-semibold ${cmvColor(cmv)}`}>
                  {fmtCmv(cmv)}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-ink-400">Margem</span>
                <span className="font-semibold text-emerald-400">
                  {brl(Number(form.salePrice || 0) - totalCost)}
                </span>
              </div>
            </div>

            <div className="border-t border-ink-700 mt-4 pt-4">
              <p className="text-xs text-ink-400 mb-2">Sugerir preço por CMV:</p>
              <div className="flex gap-2">
                {[20, 25, 30].map((t) => (
                  <button
                    type="button"
                    key={t}
                    onClick={() => suggestPrice(t)}
                    className="btn-ghost flex-1"
                  >
                    {t}%
                  </button>
                ))}
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={saving}
            className="btn-primary w-full"
          >
            {saving ? 'Salvando…' : 'Salvar receita'}
          </button>
        </div>
      </form>
    </div>
  );
}
