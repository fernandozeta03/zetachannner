import { createContext, useContext, useEffect, useState } from 'react';
import api from '../api/axios';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => {
    const raw = localStorage.getItem('baros_user');
    return raw ? JSON.parse(raw) : null;
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem('baros_token');
    if (!token) {
      setLoading(false);
      return;
    }
    api.get('/auth/me')
      .then((res) => {
        setUser(res.data);
        localStorage.setItem('baros_user', JSON.stringify(res.data));
      })
      .catch(() => {
        localStorage.removeItem('baros_token');
        localStorage.removeItem('baros_user');
        setUser(null);
      })
      .finally(() => setLoading(false));
  }, []);

  const login = async (email, password) => {
    const { data } = await api.post('/auth/login', { email, password });
    localStorage.setItem('baros_token', data.access_token);
    localStorage.setItem('baros_user', JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  };

  const register = async (payload) => {
    const { data } = await api.post('/auth/register', payload);
    localStorage.setItem('baros_token', data.access_token);
    localStorage.setItem('baros_user', JSON.stringify(data.user));
    setUser(data.user);
    return data.user;
  };

  const logout = () => {
    localStorage.removeItem('baros_token');
    localStorage.removeItem('baros_user');
    setUser(null);
  };

  const isAdmin = user?.role === 'ADMIN';
  const isBartender = user?.role === 'BARTENDER';
  const isSupplier = user?.role === 'SUPPLIER';

  return (
    <AuthContext.Provider
      value={{ user, loading, login, register, logout, isAdmin, isBartender, isSupplier }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => useContext(AuthContext);
