import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { GlassWater } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export default function Login() {
  const { login } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({ email: '', password: '' });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await login(form.email, form.password);
      toast.success('Bem-vindo ao BarOS');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Erro ao fazer login');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid place-items-center px-4 bg-ink-900">
      <div className="w-full max-w-sm">
        <div className="flex items-center gap-2 mb-8 justify-center">
          <GlassWater className="text-brand-300" size={28} />
          <h1 className="text-2xl font-semibold tracking-tight">
            Bar<span className="text-brand-300">OS</span>
          </h1>
        </div>

        <div className="card">
          <h2 className="text-lg font-semibold mb-1">Entrar</h2>
          <p className="text-sm text-ink-400 mb-6">
            Acesse o painel de gestão do seu bar.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Email</label>
              <input
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                className="input"
                placeholder="seu@email.com"
                required
              />
            </div>
            <div>
              <label className="label">Senha</label>
              <input
                name="password"
                type="password"
                value={form.password}
                onChange={handleChange}
                className="input"
                placeholder="••••••••"
                required
              />
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? 'Entrando…' : 'Entrar'}
            </button>
          </form>

          <p className="text-sm text-ink-400 mt-6 text-center">
            Não tem conta?{' '}
            <Link to="/register" className="text-brand-300 hover:underline">
              Criar conta
            </Link>
          </p>
        </div>

        <p className="text-xs text-ink-500 mt-6 text-center">
          Demo: admin@baros.dev / admin123
        </p>
      </div>
    </div>
  );
}
