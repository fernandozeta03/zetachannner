import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  OneToMany,
} from 'typeorm';
import { IngredientUnit } from '../../common/enums/ingredient-unit.enum';
import { RecipeIngredient } from '../../recipes/entities/recipe-ingredient.entity';
import { Product } from '../../products/entities/product.entity';

@Entity('ingredients')
export class Ingredient {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 120 })
  name: string;

  @Column({
    type: 'enum',
    enum: IngredientUnit,
    default: IngredientUnit.ML,
  })
  unit: IngredientUnit;

  /**
   * Custo base por unidade (ex: R$/ml, R$/g, R$/unidade).
   * Usado quando não há produto de fornecedor associado.
   */
  @Column({ type: 'numeric', precision: 12, scale: 4, default: 0 })
  baseCost: number;

  @Column({ type: 'text', nullable: true })
  description: string;

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;

  @OneToMany(() => RecipeIngredient, (ri) => ri.ingredient)
  recipeIngredients: RecipeIngredient[];

  @OneToMany(() => Product, (product) => product.ingredient)
  products: Product[];
}
