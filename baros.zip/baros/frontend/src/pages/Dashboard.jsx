import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  TrendingUp,
  Percent,
  DollarSign,
  BookOpen,
  ArrowUpRight,
  AlertTriangle,
} from 'lucide-react';
import api from '../api/axios';
import { brl, fmtCmv } from '../utils/format';

function StatCard({ icon: Icon, label, value, hint }) {
  return (
    <div className="card">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs uppercase tracking-wide text-ink-400">{label}</p>
          <p className="text-2xl font-semibold mt-2">{value}</p>
          {hint && <p className="text-xs text-ink-400 mt-1">{hint}</p>}
        </div>
        <div className="p-2 rounded-lg bg-brand-300/10 text-brand-300">
          <Icon size={20} />
        </div>
      </div>
    </div>
  );
}

export default function Dashboard() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/recipes/dashboard')
      .then((res) => setData(res.data))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <p className="text-ink-300">Carregando dashboard…</p>;
  if (!data) return null;

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between">
        <div>
          <h1 className="text-2xl font-semibold">Dashboard</h1>
          <p className="text-sm text-ink-400">
            Visão geral da operação do seu bar
          </p>
        </div>
        <Link to="/recipes/new" className="btn-primary">
          <ArrowUpRight size={16} /> Nova receita
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard
          icon={BookOpen}
          label="Receitas cadastradas"
          value={data.totalRecipes}
        />
        <StatCard
          icon={Percent}
          label="CMV médio"
          value={fmtCmv(data.averageCmv)}
          hint="Quanto menor, melhor"
        />
        <StatCard
          icon={DollarSign}
          label="Custo médio"
          value={brl(data.averageCost)}
        />
        <StatCard
          icon={TrendingUp}
          label="Preço médio"
          value={brl(data.averagePrice)}
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
        <div className="card">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="text-emerald-400" size={18} />
            <h3 className="font-semibold">Mais rentável</h3>
          </div>
          {data.mostProfitable ? (
            <Link
              to={`/recipes/${data.mostProfitable.id}`}
              className="block p-4 rounded-lg bg-ink-700 hover:bg-ink-600 transition"
            >
              <p className="font-medium">{data.mostProfitable.name}</p>
              <div className="flex gap-4 mt-1 text-sm text-ink-300">
                <span>Margem: <strong className="text-emerald-400">{brl(data.mostProfitable.margin)}</strong></span>
                <span>CMV: {fmtCmv(data.mostProfitable.cmv)}</span>
              </div>
            </Link>
          ) : (
            <p className="text-sm text-ink-400">
              Cadastre receitas com preço de venda para ver insights aqui.
            </p>
          )}
        </div>

        <div className="card">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="text-red-400" size={18} />
            <h3 className="font-semibold">Pior CMV</h3>
          </div>
          {data.worstCmv ? (
            <Link
              to={`/recipes/${data.worstCmv.id}`}
              className="block p-4 rounded-lg bg-ink-700 hover:bg-ink-600 transition"
            >
              <p className="font-medium">{data.worstCmv.name}</p>
              <p className="text-sm text-ink-300 mt-1">
                CMV: <strong className="text-red-400">{fmtCmv(data.worstCmv.cmv)}</strong>
              </p>
            </Link>
          ) : (
            <p className="text-sm text-ink-400">Sem dados ainda.</p>
          )}
        </div>
      </div>
    </div>
  );
}
