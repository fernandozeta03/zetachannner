import {
  Controller,
  Post,
  UploadedFile,
  UseGuards,
  UseInterceptors,
  BadRequestException,
} from '@nestjs/common';
import { FileInterceptor } from '@nestjs/platform-express';
import { JwtAuthGuard } from '../auth/guards/jwt-auth.guard';
import { RolesGuard } from '../common/guards/roles.guard';
import { Roles } from '../common/decorators/roles.decorator';
import { UserRole } from '../common/enums/user-role.enum';

/**
 * FASE 2 - estrutura preparada. Retorna mock estruturado simulando uma
 * extração de receita a partir de imagem. Substituir por integração real
 * (Tesseract / Google Vision / GPT-4V / Claude Vision).
 */
@Controller('ocr')
@UseGuards(JwtAuthGuard, RolesGuard)
export class OcrController {
  @Post('scan')
  @Roles(UserRole.ADMIN)
  @UseInterceptors(FileInterceptor('file'))
  scan(@UploadedFile() file: Express.Multer.File) {
    if (!file) {
      throw new BadRequestException('Nenhuma imagem enviada (campo: file)');
    }

    // MOCK – formato compatível com CreateRecipeDto (faltando ingredientId real)
    return {
      success: true,
      filename: file.originalname,
      sizeBytes: file.size,
      extracted: {
        name: 'Negroni',
        category: 'Drink Clássico',
        glassware: 'Old Fashioned',
        garnish: 'Casca de laranja',
        preparation:
          'Adicione todos os ingredientes em um copo baixo com gelo, mexa por 20 segundos e finalize com a casca de laranja.',
        ingredients: [
          { name: 'Gin', unit: 'ml', quantity: 30 },
          { name: 'Campari', unit: 'ml', quantity: 30 },
          { name: 'Vermute Tinto', unit: 'ml', quantity: 30 },
        ],
      },
      hint:
        'Crie/associe os ingredientes em /api/ingredients antes de criar a receita em /api/recipes.',
    };
  }
}
