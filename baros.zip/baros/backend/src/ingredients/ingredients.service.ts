import { Injectable, NotFoundException } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Ingredient } from './entities/ingredient.entity';
import { CreateIngredientDto } from './dto/create-ingredient.dto';
import { UpdateIngredientDto } from './dto/update-ingredient.dto';

@Injectable()
export class IngredientsService {
  constructor(
    @InjectRepository(Ingredient)
    private readonly ingredientRepository: Repository<Ingredient>,
  ) {}

  create(dto: CreateIngredientDto) {
    const ingredient = this.ingredientRepository.create(dto);
    return this.ingredientRepository.save(ingredient);
  }

  findAll() {
    return this.ingredientRepository.find({ order: { name: 'ASC' } });
  }

  async findOne(id: string) {
    const ingredient = await this.ingredientRepository.findOne({
      where: { id },
      relations: ['products', 'products.supplier'],
    });
    if (!ingredient) {
      throw new NotFoundException('Ingrediente não encontrado');
    }
    return ingredient;
  }

  async update(id: string, dto: UpdateIngredientDto) {
    const ingredient = await this.findOne(id);
    Object.assign(ingredient, dto);
    return this.ingredientRepository.save(ingredient);
  }

  async remove(id: string) {
    const ingredient = await this.findOne(id);
    await this.ingredientRepository.remove(ingredient);
    return { deleted: true };
  }
}
