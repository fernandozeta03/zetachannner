import { Injectable, NotFoundException, Logger } from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Product } from './entities/product.entity';
import { CreateProductDto } from './dto/create-product.dto';
import { UpdatePriceDto } from './dto/update-price.dto';
import { Ingredient } from '../ingredients/entities/ingredient.entity';
import { RecipesService } from '../recipes/recipes.service';

@Injectable()
export class ProductsService {
  private readonly logger = new Logger(ProductsService.name);

  constructor(
    @InjectRepository(Product)
    private readonly productRepository: Repository<Product>,
    @InjectRepository(Ingredient)
    private readonly ingredientRepository: Repository<Ingredient>,
    private readonly recipesService: RecipesService,
  ) {}

  async create(dto: CreateProductDto) {
    const product = this.productRepository.create(dto);
    const saved = await this.productRepository.save(product);

    // Sincroniza baseCost do ingrediente com o menor preço disponível
    await this.syncIngredientCost(dto.ingredientId);

    return this.productRepository.findOne({
      where: { id: saved.id },
      relations: ['supplier', 'ingredient'],
    });
  }

  findAll() {
    return this.productRepository.find({
      relations: ['supplier', 'ingredient'],
      order: { updatedAt: 'DESC' },
    });
  }

  findBySupplier(supplierId: string) {
    return this.productRepository.find({
      where: { supplierId },
      relations: ['ingredient'],
    });
  }

  async findOne(id: string) {
    const product = await this.productRepository.findOne({
      where: { id },
      relations: ['supplier', 'ingredient'],
    });
    if (!product) throw new NotFoundException('Produto não encontrado');
    return product;
  }

  /**
   * REGRA DE NEGÓCIO 4: ao atualizar preço, propagar para o ingrediente
   * e recalcular todas as receitas que o utilizam.
   */
  async updatePrice(id: string, dto: UpdatePriceDto) {
    const product = await this.findOne(id);
    product.price = dto.price;
    await this.productRepository.save(product);

    await this.syncIngredientCost(product.ingredientId);
    const recalculated = await this.recipesService.recalculateAllByIngredient(
      product.ingredientId,
    );

    this.logger.log(
      `Preço do produto ${id} atualizado. ${recalculated} receita(s) recalculada(s).`,
    );

    return {
      product,
      recalculatedRecipes: recalculated,
    };
  }

  async remove(id: string) {
    const product = await this.findOne(id);
    const ingredientId = product.ingredientId;
    await this.productRepository.remove(product);
    await this.syncIngredientCost(ingredientId);
    return { deleted: true };
  }

  /**
   * Define o baseCost do ingrediente como o MENOR preço entre fornecedores
   * (regra simples: usar o melhor preço disponível). Se não houver produtos,
   * mantém o baseCost atual.
   */
  private async syncIngredientCost(ingredientId: string) {
    const products = await this.productRepository.find({
      where: { ingredientId },
    });
    if (products.length === 0) return;

    const minPrice = products.reduce(
      (min, p) => Math.min(min, Number(p.price)),
      Number(products[0].price),
    );

    await this.ingredientRepository.update(
      { id: ingredientId },
      { baseCost: minPrice },
    );
  }
}
