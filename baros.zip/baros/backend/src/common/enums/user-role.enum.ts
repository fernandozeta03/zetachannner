export enum UserRole {
  ADMIN = 'ADMIN',
  BARTENDER = 'BARTENDER',
  SUPPLIER = 'SUPPLIER',
}
