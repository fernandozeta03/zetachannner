import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { Plus, Trash2, Pencil, X } from 'lucide-react';
import api from '../api/axios';
import { brl } from '../utils/format';
import { useAuth } from '../context/AuthContext';

const UNITS = ['ml', 'l', 'g', 'kg', 'unidade', 'dash'];

const blank = { name: '', unit: 'ml', baseCost: 0, description: '' };

export default function Ingredients() {
  const { isAdmin } = useAuth();
  const [list, setList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState(null);
  const [form, setForm] = useState(blank);

  const load = () =>
    api.get('/ingredients').then((res) => setList(res.data));

  useEffect(() => {
    load().finally(() => setLoading(false));
  }, []);

  const startCreate = () => {
    setEditing(null);
    setForm(blank);
    setShowForm(true);
  };

  const startEdit = (ing) => {
    setEditing(ing.id);
    setForm({
      name: ing.name,
      unit: ing.unit,
      baseCost: ing.baseCost,
      description: ing.description || '',
    });
    setShowForm(true);
  };

  const save = async (e) => {
    e.preventDefault();
    try {
      const payload = { ...form, baseCost: Number(form.baseCost) };
      if (editing) {
        await api.patch(`/ingredients/${editing}`, payload);
        toast.success('Atualizado');
      } else {
        await api.post('/ingredients', payload);
        toast.success('Ingrediente criado');
      }
      setShowForm(false);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Erro');
    }
  };

  const remove = async (id) => {
    if (!window.confirm('Excluir ingrediente?')) return;
    try {
      await api.delete(`/ingredients/${id}`);
      toast.success('Excluído');
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Não foi possível excluir');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Ingredientes</h1>
          <p className="text-sm text-ink-400">
            Insumos usados nas suas fichas técnicas
          </p>
        </div>
        {isAdmin && (
          <button onClick={startCreate} className="btn-primary">
            <Plus size={16} /> Novo ingrediente
          </button>
        )}
      </div>

      {showForm && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">
              {editing ? 'Editar' : 'Novo'} ingrediente
            </h3>
            <button onClick={() => setShowForm(false)} className="btn-ghost">
              <X size={14} />
            </button>
          </div>
          <form onSubmit={save} className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <label className="label">Nome *</label>
              <input
                className="input"
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
            </div>
            <div>
              <label className="label">Unidade *</label>
              <select
                className="input"
                value={form.unit}
                onChange={(e) => setForm({ ...form, unit: e.target.value })}
              >
                {UNITS.map((u) => (
                  <option key={u} value={u}>
                    {u}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Custo por unidade (R$)</label>
              <input
                type="number"
                step="0.0001"
                min="0"
                className="input"
                value={form.baseCost}
                onChange={(e) => setForm({ ...form, baseCost: e.target.value })}
              />
            </div>
            <div className="md:col-span-4">
              <label className="label">Descrição</label>
              <input
                className="input"
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>
            <div className="md:col-span-4 flex justify-end">
              <button type="submit" className="btn-primary">
                {editing ? 'Salvar alterações' : 'Criar ingrediente'}
              </button>
            </div>
          </form>
        </div>
      )}

      <div className="card overflow-x-auto">
        {loading ? (
          <p className="text-ink-300">Carregando…</p>
        ) : list.length === 0 ? (
          <p className="text-ink-400 text-center py-8">
            Nenhum ingrediente ainda.
          </p>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-ink-400">
              <tr className="text-left border-b border-ink-700">
                <th className="py-2">Nome</th>
                <th className="py-2">Unidade</th>
                <th className="py-2 text-right">Custo base</th>
                {isAdmin && <th className="py-2 text-right">Ações</th>}
              </tr>
            </thead>
            <tbody>
              {list.map((ing) => (
                <tr key={ing.id} className="border-b border-ink-700/50">
                  <td className="py-3">{ing.name}</td>
                  <td className="py-3 text-ink-300">{ing.unit}</td>
                  <td className="py-3 text-right">
                    {brl(ing.baseCost)} / {ing.unit}
                  </td>
                  {isAdmin && (
                    <td className="py-3 text-right">
                      <div className="inline-flex gap-2">
                        <button
                          onClick={() => startEdit(ing)}
                          className="btn-ghost"
                        >
                          <Pencil size={14} />
                        </button>
                        <button
                          onClick={() => remove(ing.id)}
                          className="btn-ghost text-red-400"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
