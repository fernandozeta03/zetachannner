import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import toast from 'react-hot-toast';
import { GlassWater } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

export default function Register() {
  const { register } = useAuth();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: '',
    email: '',
    password: '',
    role: 'ADMIN',
  });
  const [loading, setLoading] = useState(false);

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      await register(form);
      toast.success('Conta criada com sucesso');
      navigate('/dashboard');
    } catch (err) {
      toast.error(err.response?.data?.message || 'Erro ao criar conta');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid place-items-center px-4 bg-ink-900">
      <div className="w-full max-w-sm">
        <div className="flex items-center gap-2 mb-8 justify-center">
          <GlassWater className="text-brand-300" size={28} />
          <h1 className="text-2xl font-semibold tracking-tight">
            Bar<span className="text-brand-300">OS</span>
          </h1>
        </div>

        <div className="card">
          <h2 className="text-lg font-semibold mb-1">Criar conta</h2>
          <p className="text-sm text-ink-400 mb-6">
            Comece a profissionalizar seu bar agora.
          </p>

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="label">Nome</label>
              <input
                name="name"
                value={form.name}
                onChange={handleChange}
                className="input"
                required
              />
            </div>
            <div>
              <label className="label">Email</label>
              <input
                name="email"
                type="email"
                value={form.email}
                onChange={handleChange}
                className="input"
                required
              />
            </div>
            <div>
              <label className="label">Senha</label>
              <input
                name="password"
                type="password"
                value={form.password}
                onChange={handleChange}
                className="input"
                minLength={6}
                required
              />
            </div>
            <div>
              <label className="label">Tipo de conta</label>
              <select
                name="role"
                value={form.role}
                onChange={handleChange}
                className="input"
              >
                <option value="ADMIN">Chefe de Bar (Admin)</option>
                <option value="BARTENDER">Bartender</option>
                <option value="SUPPLIER">Fornecedor</option>
              </select>
            </div>

            <button type="submit" disabled={loading} className="btn-primary w-full">
              {loading ? 'Criando…' : 'Criar conta'}
            </button>
          </form>

          <p className="text-sm text-ink-400 mt-6 text-center">
            Já tem conta?{' '}
            <Link to="/login" className="text-brand-300 hover:underline">
              Entrar
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
}
