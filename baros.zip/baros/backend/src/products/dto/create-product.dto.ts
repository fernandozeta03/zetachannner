import { IsNumber, IsOptional, IsString, IsUUID, Min } from 'class-validator';

export class CreateProductDto {
  @IsUUID()
  supplierId: string;

  @IsUUID()
  ingredientId: string;

  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  price: number;

  @IsOptional()
  @IsString()
  sku?: string;
}
