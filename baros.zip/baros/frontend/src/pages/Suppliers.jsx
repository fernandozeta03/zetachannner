import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { Plus, Trash2, X } from 'lucide-react';
import api from '../api/axios';
import { useAuth } from '../context/AuthContext';

const blank = { name: '', contact: '', email: '', phone: '' };

export default function Suppliers() {
  const { isAdmin } = useAuth();
  const [list, setList] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(blank);

  const load = () => api.get('/suppliers').then((r) => setList(r.data));
  useEffect(() => { load(); }, []);

  const save = async (e) => {
    e.preventDefault();
    try {
      await api.post('/suppliers', form);
      toast.success('Fornecedor cadastrado');
      setShowForm(false);
      setForm(blank);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Erro');
    }
  };

  const remove = async (id) => {
    if (!window.confirm('Excluir fornecedor?')) return;
    await api.delete(`/suppliers/${id}`);
    toast.success('Excluído');
    load();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Fornecedores</h1>
          <p className="text-sm text-ink-400">Quem abastece seu bar</p>
        </div>
        <button onClick={() => setShowForm(true)} className="btn-primary">
          <Plus size={16} /> Novo fornecedor
        </button>
      </div>

      {showForm && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Novo fornecedor</h3>
            <button onClick={() => setShowForm(false)} className="btn-ghost">
              <X size={14} />
            </button>
          </div>
          <form onSubmit={save} className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="label">Nome *</label>
              <input className="input" value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })} required />
            </div>
            <div>
              <label className="label">Contato (responsável)</label>
              <input className="input" value={form.contact}
                onChange={(e) => setForm({ ...form, contact: e.target.value })} />
            </div>
            <div>
              <label className="label">Email</label>
              <input type="email" className="input" value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })} />
            </div>
            <div>
              <label className="label">Telefone</label>
              <input className="input" value={form.phone}
                onChange={(e) => setForm({ ...form, phone: e.target.value })} />
            </div>
            <div className="md:col-span-2 flex justify-end">
              <button type="submit" className="btn-primary">Cadastrar</button>
            </div>
          </form>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {list.map((s) => (
          <div key={s.id} className="card">
            <div className="flex items-start justify-between">
              <div>
                <h3 className="font-semibold">{s.name}</h3>
                {s.contact && <p className="text-sm text-ink-300 mt-1">{s.contact}</p>}
                <div className="text-xs text-ink-400 mt-2 space-y-0.5">
                  {s.email && <p>{s.email}</p>}
                  {s.phone && <p>{s.phone}</p>}
                </div>
              </div>
              {isAdmin && (
                <button onClick={() => remove(s.id)} className="btn-ghost text-red-400">
                  <Trash2 size={14} />
                </button>
              )}
            </div>
            <div className="mt-3 pt-3 border-t border-ink-700">
              <p className="text-xs text-ink-400">
                {s.products?.length || 0} produto(s) cadastrado(s)
              </p>
            </div>
          </div>
        ))}
        {list.length === 0 && (
          <p className="text-ink-400 col-span-full text-center py-8">
            Nenhum fornecedor cadastrado.
          </p>
        )}
      </div>
    </div>
  );
}
