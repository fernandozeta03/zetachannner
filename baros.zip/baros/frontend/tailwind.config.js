/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx,ts,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          50:  '#fdf6e3',
          100: '#fbe9b6',
          200: '#f7d27a',
          300: '#f0b941',
          400: '#e09a16',
          500: '#b87a0a',
          600: '#8e5c08',
          700: '#674209',
          800: '#42290a',
          900: '#231507',
        },
        ink: {
          900: '#0b0b0d',
          800: '#16161a',
          700: '#1f1f25',
          600: '#2a2a32',
          500: '#3a3a44',
          400: '#6b6b78',
          300: '#a0a0ad',
          200: '#d4d4dc',
          100: '#ececf1',
        },
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
