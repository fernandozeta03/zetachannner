import {
  BadRequestException,
  Injectable,
  NotFoundException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { In, Repository } from 'typeorm';
import { Recipe } from './entities/recipe.entity';
import { RecipeIngredient } from './entities/recipe-ingredient.entity';
import { Ingredient } from '../ingredients/entities/ingredient.entity';
import { CreateRecipeDto, RecipeIngredientDto } from './dto/create-recipe.dto';
import { UpdateRecipeDto } from './dto/update-recipe.dto';

@Injectable()
export class RecipesService {
  constructor(
    @InjectRepository(Recipe)
    private readonly recipeRepository: Repository<Recipe>,
    @InjectRepository(RecipeIngredient)
    private readonly recipeIngredientRepository: Repository<RecipeIngredient>,
    @InjectRepository(Ingredient)
    private readonly ingredientRepository: Repository<Ingredient>,
  ) {}

  // ========================================================================
  // REGRA DE NEGÓCIO CENTRAL — CÁLCULO DE CUSTO E CMV
  // ========================================================================

  /**
   * custo_total = Σ (quantidade × custo_base do ingrediente)
   * CMV (%)    = (custo_total / preco_venda) × 100
   */
  private async computeCostAndCmv(
    items: RecipeIngredientDto[],
    salePrice: number,
  ): Promise<{ totalCost: number; cmv: number; lines: { ingredient: Ingredient; quantity: number; cost: number }[] }> {
    const ids = items.map((i) => i.ingredientId);
    const ingredients = await this.ingredientRepository.find({
      where: { id: In(ids) },
    });

    if (ingredients.length !== ids.length) {
      throw new BadRequestException(
        'Um ou mais ingredientes informados não existem',
      );
    }

    const byId = new Map(ingredients.map((i) => [i.id, i]));

    let totalCost = 0;
    const lines = items.map((item) => {
      const ingredient = byId.get(item.ingredientId)!;
      const baseCost = Number(ingredient.baseCost) || 0;
      const lineCost = Number(item.quantity) * baseCost;
      totalCost += lineCost;
      return {
        ingredient,
        quantity: Number(item.quantity),
        cost: Number(lineCost.toFixed(4)),
      };
    });

    totalCost = Number(totalCost.toFixed(4));
    const cmv =
      salePrice > 0 ? Number(((totalCost / salePrice) * 100).toFixed(2)) : 0;

    return { totalCost, cmv, lines };
  }

  // ========================================================================
  // CRUD
  // ========================================================================

  async create(dto: CreateRecipeDto, userId: string): Promise<Recipe> {
    const salePrice = Number(dto.salePrice ?? 0);
    const { totalCost, cmv, lines } = await this.computeCostAndCmv(
      dto.ingredients,
      salePrice,
    );

    const recipe = this.recipeRepository.create({
      name: dto.name,
      category: dto.category ?? 'Drink',
      preparation: dto.preparation,
      garnish: dto.garnish,
      glassware: dto.glassware,
      salePrice,
      totalCost,
      cmv,
      userId,
      ingredients: lines.map((l) =>
        this.recipeIngredientRepository.create({
          ingredientId: l.ingredient.id,
          quantity: l.quantity,
          cost: l.cost,
        }),
      ),
    });

    return this.recipeRepository.save(recipe);
  }

  findAll(): Promise<Recipe[]> {
    return this.recipeRepository.find({
      order: { createdAt: 'DESC' },
    });
  }

  async findOne(id: string): Promise<Recipe> {
    const recipe = await this.recipeRepository.findOne({
      where: { id },
      relations: ['user', 'ingredients', 'ingredients.ingredient'],
    });
    if (!recipe) throw new NotFoundException('Receita não encontrada');
    return recipe;
  }

  async update(id: string, dto: UpdateRecipeDto): Promise<Recipe> {
    const recipe = await this.findOne(id);

    // Atualiza campos simples
    if (dto.name !== undefined) recipe.name = dto.name;
    if (dto.category !== undefined) recipe.category = dto.category;
    if (dto.preparation !== undefined) recipe.preparation = dto.preparation;
    if (dto.garnish !== undefined) recipe.garnish = dto.garnish;
    if (dto.glassware !== undefined) recipe.glassware = dto.glassware;
    if (dto.salePrice !== undefined) recipe.salePrice = Number(dto.salePrice);

    // Se ingredientes ou preço mudaram, recalcular
    if (dto.ingredients !== undefined || dto.salePrice !== undefined) {
      const items = dto.ingredients
        ? dto.ingredients
        : recipe.ingredients.map((ri) => ({
            ingredientId: ri.ingredientId,
            quantity: Number(ri.quantity),
          }));

      const { totalCost, cmv, lines } = await this.computeCostAndCmv(
        items,
        Number(recipe.salePrice),
      );

      recipe.totalCost = totalCost;
      recipe.cmv = cmv;

      if (dto.ingredients !== undefined) {
        // Substitui ingredientes (cascade + orphan via remove explícito)
        await this.recipeIngredientRepository.delete({ recipeId: recipe.id });
        recipe.ingredients = lines.map((l) =>
          this.recipeIngredientRepository.create({
            ingredientId: l.ingredient.id,
            quantity: l.quantity,
            cost: l.cost,
          }),
        );
      }
    }

    return this.recipeRepository.save(recipe);
  }

  async remove(id: string) {
    const recipe = await this.findOne(id);
    await this.recipeRepository.remove(recipe);
    return { deleted: true };
  }

  // ========================================================================
  // SUGESTÃO DE PREÇO
  // ========================================================================
  /**
   * preco_sugerido = custo_total / (CMV_alvo / 100)
   */
  async suggestPrice(id: string, targetCmv: number) {
    const recipe = await this.findOne(id);
    const cost = Number(recipe.totalCost);

    if (targetCmv <= 0) {
      throw new BadRequestException('CMV alvo deve ser > 0');
    }

    const suggestedPrice = Number((cost / (targetCmv / 100)).toFixed(2));
    return {
      recipeId: id,
      totalCost: cost,
      currentSalePrice: Number(recipe.salePrice),
      currentCmv: Number(recipe.cmv),
      targetCmv,
      suggestedPrice,
    };
  }

  // ========================================================================
  // RECÁLCULO EM CASCATA (regra: se preço do ingrediente mudar, recalcular)
  // ========================================================================
  async recalculateAllByIngredient(ingredientId: string): Promise<number> {
    const lines = await this.recipeIngredientRepository.find({
      where: { ingredientId },
      relations: ['recipe'],
    });

    const recipeIds = Array.from(new Set(lines.map((l) => l.recipeId)));
    let updated = 0;

    for (const recipeId of recipeIds) {
      const recipe = await this.recipeRepository.findOne({
        where: { id: recipeId },
        relations: ['ingredients', 'ingredients.ingredient'],
      });
      if (!recipe) continue;

      const items = recipe.ingredients.map((ri) => ({
        ingredientId: ri.ingredientId,
        quantity: Number(ri.quantity),
      }));

      const { totalCost, cmv, lines: newLines } = await this.computeCostAndCmv(
        items,
        Number(recipe.salePrice),
      );

      recipe.totalCost = totalCost;
      recipe.cmv = cmv;

      // Atualiza snapshots de cost por linha
      for (const ri of recipe.ingredients) {
        const match = newLines.find(
          (nl) => nl.ingredient.id === ri.ingredientId,
        );
        if (match) ri.cost = match.cost;
      }

      await this.recipeRepository.save(recipe);
      updated++;
    }

    return updated;
  }

  // ========================================================================
  // DASHBOARD
  // ========================================================================
  async dashboard() {
    const recipes = await this.recipeRepository.find();
    const total = recipes.length;

    if (total === 0) {
      return {
        totalRecipes: 0,
        averageCmv: 0,
        averageCost: 0,
        averagePrice: 0,
        mostProfitable: null,
        worstCmv: null,
      };
    }

    const sumCmv = recipes.reduce((s, r) => s + Number(r.cmv || 0), 0);
    const sumCost = recipes.reduce((s, r) => s + Number(r.totalCost || 0), 0);
    const sumPrice = recipes.reduce((s, r) => s + Number(r.salePrice || 0), 0);

    // Mais rentável = maior margem absoluta (preço - custo), ignorando preço 0
    const priced = recipes.filter((r) => Number(r.salePrice) > 0);
    const mostProfitable =
      priced.length > 0
        ? priced.reduce((best, r) =>
            Number(r.salePrice) - Number(r.totalCost) >
            Number(best.salePrice) - Number(best.totalCost)
              ? r
              : best,
          )
        : null;

    const worstCmv =
      priced.length > 0
        ? priced.reduce((worst, r) =>
            Number(r.cmv) > Number(worst.cmv) ? r : worst,
          )
        : null;

    return {
      totalRecipes: total,
      averageCmv: Number((sumCmv / total).toFixed(2)),
      averageCost: Number((sumCost / total).toFixed(2)),
      averagePrice: Number((sumPrice / total).toFixed(2)),
      mostProfitable: mostProfitable
        ? {
            id: mostProfitable.id,
            name: mostProfitable.name,
            margin: Number(
              (
                Number(mostProfitable.salePrice) -
                Number(mostProfitable.totalCost)
              ).toFixed(2),
            ),
            cmv: Number(mostProfitable.cmv),
          }
        : null,
      worstCmv: worstCmv
        ? {
            id: worstCmv.id,
            name: worstCmv.name,
            cmv: Number(worstCmv.cmv),
          }
        : null,
    };
  }
}
