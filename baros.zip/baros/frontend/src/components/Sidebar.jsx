import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  BookOpen,
  Beaker,
  Truck,
  Package,
  GlassWater,
} from 'lucide-react';

const items = [
  { to: '/dashboard',   label: 'Dashboard',    icon: LayoutDashboard },
  { to: '/recipes',     label: 'Receitas',     icon: BookOpen },
  { to: '/ingredients', label: 'Ingredientes', icon: Beaker },
  { to: '/suppliers',   label: 'Fornecedores', icon: Truck },
  { to: '/products',    label: 'Produtos',     icon: Package },
];

export default function Sidebar() {
  return (
    <aside className="w-60 shrink-0 border-r border-ink-700 bg-ink-800 flex flex-col">
      <div className="px-6 h-16 flex items-center gap-2 border-b border-ink-700">
        <GlassWater className="text-brand-300" size={22} />
        <span className="text-lg font-semibold tracking-tight">
          Bar<span className="text-brand-300">OS</span>
        </span>
      </div>

      <nav className="flex-1 p-3 space-y-1">
        {items.map(({ to, label, icon: Icon }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              `flex items-center gap-3 px-3 py-2 rounded-lg text-sm transition ${
                isActive
                  ? 'bg-ink-700 text-brand-300'
                  : 'text-ink-300 hover:bg-ink-700 hover:text-ink-100'
              }`
            }
          >
            <Icon size={18} />
            {label}
          </NavLink>
        ))}
      </nav>

      <div className="p-3 text-[11px] text-ink-400 border-t border-ink-700">
        BarOS v1.0 · MVP
      </div>
    </aside>
  );
}
