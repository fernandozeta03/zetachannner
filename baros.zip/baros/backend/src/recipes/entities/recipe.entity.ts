import {
  Entity,
  PrimaryGeneratedColumn,
  Column,
  CreateDateColumn,
  UpdateDateColumn,
  ManyToOne,
  OneToMany,
  JoinColumn,
} from 'typeorm';
import { User } from '../../users/entities/user.entity';
import { RecipeIngredient } from './recipe-ingredient.entity';

@Entity('recipes')
export class Recipe {
  @PrimaryGeneratedColumn('uuid')
  id: string;

  @Column({ length: 160 })
  name: string;

  @Column({ length: 80, default: 'Drink' })
  category: string;

  @Column({ type: 'text', nullable: true })
  preparation: string;

  @Column({ length: 160, nullable: true })
  garnish: string;

  @Column({ length: 80, nullable: true })
  glassware: string;

  /**
   * Custo total calculado dinamicamente (snapshot).
   * Recalculado sempre que ingredientes ou preço mudam.
   */
  @Column({ type: 'numeric', precision: 12, scale: 4, default: 0 })
  totalCost: number;

  @Column({ type: 'numeric', precision: 12, scale: 2, default: 0 })
  salePrice: number;

  /**
   * CMV em % = (totalCost / salePrice) * 100
   */
  @Column({ type: 'numeric', precision: 5, scale: 2, default: 0 })
  cmv: number;

  @ManyToOne(() => User, (user) => user.recipes, {
    onDelete: 'SET NULL',
    nullable: true,
  })
  @JoinColumn({ name: 'user_id' })
  user: User;

  @Column({ name: 'user_id', nullable: true })
  userId: string;

  @OneToMany(() => RecipeIngredient, (ri) => ri.recipe, {
    cascade: true,
    eager: true,
  })
  ingredients: RecipeIngredient[];

  @CreateDateColumn()
  createdAt: Date;

  @UpdateDateColumn()
  updatedAt: Date;
}
