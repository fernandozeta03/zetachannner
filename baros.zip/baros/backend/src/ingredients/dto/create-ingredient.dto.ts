import { IsEnum, IsNotEmpty, IsNumber, IsOptional, IsString, Min } from 'class-validator';
import { IngredientUnit } from '../../common/enums/ingredient-unit.enum';

export class CreateIngredientDto {
  @IsNotEmpty({ message: 'Nome é obrigatório' })
  @IsString()
  name: string;

  @IsEnum(IngredientUnit, { message: 'Unidade inválida' })
  unit: IngredientUnit;

  @IsNumber({ maxDecimalPlaces: 4 })
  @Min(0)
  baseCost: number;

  @IsOptional()
  @IsString()
  description?: string;
}
