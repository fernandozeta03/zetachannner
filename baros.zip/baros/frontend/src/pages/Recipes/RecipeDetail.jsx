import { useEffect, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import toast from 'react-hot-toast';
import { ArrowLeft, Trash2, GlassWater } from 'lucide-react';
import api from '../../api/axios';
import { brl, fmtCmv, cmvColor } from '../../utils/format';
import { useAuth } from '../../context/AuthContext';

export default function RecipeDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isAdmin } = useAuth();
  const [recipe, setRecipe] = useState(null);
  const [suggested, setSuggested] = useState(null);

  const load = () =>
    api.get(`/recipes/${id}`).then((res) => setRecipe(res.data));

  useEffect(() => {
    load();
  }, [id]);

  const suggestPrice = async (target) => {
    const { data } = await api.get(`/recipes/${id}/suggest-price`, {
      params: { targetCmv: target },
    });
    setSuggested(data);
  };

  const remove = async () => {
    if (!window.confirm('Excluir esta receita?')) return;
    await api.delete(`/recipes/${id}`);
    toast.success('Receita excluída');
    navigate('/recipes');
  };

  if (!recipe) return <p className="text-ink-300">Carregando…</p>;

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-center justify-between flex-wrap gap-3">
        <Link to="/recipes" className="btn-ghost">
          <ArrowLeft size={14} /> Voltar
        </Link>
        {isAdmin && (
          <button onClick={remove} className="btn-danger">
            <Trash2 size={14} /> Excluir
          </button>
        )}
      </div>

      <div className="card">
        <div className="flex items-start justify-between flex-wrap gap-4">
          <div className="flex items-center gap-4">
            <div className="p-3 rounded-xl bg-brand-300/10 text-brand-300">
              <GlassWater size={28} />
            </div>
            <div>
              <p className="text-xs uppercase tracking-wide text-ink-400">
                {recipe.category}
              </p>
              <h1 className="text-2xl font-semibold">{recipe.name}</h1>
              <p className="text-sm text-ink-400 mt-1">
                {recipe.glassware} · garnish: {recipe.garnish || '—'}
              </p>
            </div>
          </div>

          <div className="text-right">
            <p className="text-xs text-ink-400">CMV</p>
            <p className={`text-3xl font-bold ${cmvColor(recipe.cmv)}`}>
              {fmtCmv(recipe.cmv)}
            </p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="card">
          <p className="text-xs text-ink-400">Custo total</p>
          <p className="text-2xl font-semibold mt-1">{brl(recipe.totalCost)}</p>
        </div>
        <div className="card">
          <p className="text-xs text-ink-400">Preço de venda</p>
          <p className="text-2xl font-semibold mt-1">{brl(recipe.salePrice)}</p>
        </div>
        <div className="card">
          <p className="text-xs text-ink-400">Margem</p>
          <p className="text-2xl font-semibold mt-1 text-emerald-400">
            {brl(Number(recipe.salePrice) - Number(recipe.totalCost))}
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 card">
          <h3 className="font-semibold mb-4">Ingredientes</h3>
          <table className="w-full text-sm">
            <thead className="text-ink-400">
              <tr className="text-left border-b border-ink-700">
                <th className="py-2">Ingrediente</th>
                <th className="py-2">Quantidade</th>
                <th className="py-2 text-right">Custo</th>
              </tr>
            </thead>
            <tbody>
              {recipe.ingredients?.map((ri) => (
                <tr key={ri.id} className="border-b border-ink-700/50">
                  <td className="py-2.5">{ri.ingredient?.name}</td>
                  <td className="py-2.5">
                    {Number(ri.quantity)} {ri.ingredient?.unit}
                  </td>
                  <td className="py-2.5 text-right">{brl(ri.cost)}</td>
                </tr>
              ))}
            </tbody>
          </table>

          {recipe.preparation && (
            <div className="mt-6">
              <h4 className="font-semibold text-sm mb-2">Modo de preparo</h4>
              <p className="text-sm text-ink-200 leading-relaxed whitespace-pre-line">
                {recipe.preparation}
              </p>
            </div>
          )}
        </div>

        <div className="card">
          <h3 className="font-semibold mb-3">Sugerir preço</h3>
          <p className="text-xs text-ink-400 mb-3">
            Baseado em CMV alvo:
          </p>
          <div className="flex gap-2 mb-4">
            {[20, 25, 30].map((t) => (
              <button
                key={t}
                onClick={() => suggestPrice(t)}
                className="btn-ghost flex-1"
              >
                {t}%
              </button>
            ))}
          </div>
          {suggested && (
            <div className="p-3 rounded-lg bg-brand-300/10 border border-brand-300/30">
              <p className="text-xs text-ink-400">
                Para CMV alvo de {suggested.targetCmv}%:
              </p>
              <p className="text-2xl font-bold text-brand-300 mt-1">
                {brl(suggested.suggestedPrice)}
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
