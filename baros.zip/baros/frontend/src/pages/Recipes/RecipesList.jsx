import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { Plus, Search, BookOpen } from 'lucide-react';
import api from '../../api/axios';
import { brl, fmtCmv, cmvColor } from '../../utils/format';
import { useAuth } from '../../context/AuthContext';

export default function RecipesList() {
  const { isAdmin } = useAuth();
  const [recipes, setRecipes] = useState([]);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    api.get('/recipes')
      .then((res) => setRecipes(res.data))
      .finally(() => setLoading(false));
  }, []);

  const filtered = recipes.filter((r) =>
    r.name.toLowerCase().includes(q.toLowerCase()),
  );

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-semibold">Receitas</h1>
          <p className="text-sm text-ink-400">Suas fichas técnicas</p>
        </div>
        {isAdmin && (
          <Link to="/recipes/new" className="btn-primary">
            <Plus size={16} /> Nova receita
          </Link>
        )}
      </div>

      <div className="relative max-w-sm">
        <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar receita…"
          className="input pl-9"
        />
      </div>

      {loading ? (
        <p className="text-ink-300">Carregando…</p>
      ) : filtered.length === 0 ? (
        <div className="card text-center py-12">
          <BookOpen className="mx-auto text-ink-500" size={32} />
          <p className="mt-3 text-ink-300">
            {recipes.length === 0
              ? 'Nenhuma receita cadastrada ainda.'
              : 'Nenhum resultado para a busca.'}
          </p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((r) => (
            <Link
              key={r.id}
              to={`/recipes/${r.id}`}
              className="card hover:border-brand-300/50 hover:bg-ink-700/50 transition"
            >
              <div className="flex items-start justify-between">
                <div>
                  <p className="text-xs uppercase tracking-wide text-ink-400">
                    {r.category}
                  </p>
                  <h3 className="font-semibold text-lg mt-1">{r.name}</h3>
                </div>
                <span className={`badge bg-ink-700 ${cmvColor(r.cmv)}`}>
                  CMV {fmtCmv(r.cmv)}
                </span>
              </div>

              <div className="mt-4 grid grid-cols-2 gap-3 text-sm">
                <div>
                  <p className="text-ink-400 text-xs">Custo</p>
                  <p className="font-medium">{brl(r.totalCost)}</p>
                </div>
                <div>
                  <p className="text-ink-400 text-xs">Venda</p>
                  <p className="font-medium">{brl(r.salePrice)}</p>
                </div>
              </div>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
