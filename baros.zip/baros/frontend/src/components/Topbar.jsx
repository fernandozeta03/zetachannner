import { LogOut } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const roleLabel = {
  ADMIN: 'Administrador',
  BARTENDER: 'Bartender',
  SUPPLIER: 'Fornecedor',
};

export default function Topbar() {
  const { user, logout } = useAuth();

  return (
    <header className="h-16 border-b border-ink-700 bg-ink-800 flex items-center justify-between px-6">
      <div>
        <p className="text-xs text-ink-400">Bem-vindo de volta</p>
        <p className="text-sm font-medium">{user?.name}</p>
      </div>

      <div className="flex items-center gap-3">
        <span className="badge bg-ink-700 text-ink-200 border border-ink-600">
          {roleLabel[user?.role] ?? user?.role}
        </span>
        <button
          onClick={logout}
          className="btn-ghost"
          title="Sair"
        >
          <LogOut size={16} />
          <span>Sair</span>
        </button>
      </div>
    </header>
  );
}
