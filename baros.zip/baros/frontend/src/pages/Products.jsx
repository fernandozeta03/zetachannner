import { useEffect, useState } from 'react';
import toast from 'react-hot-toast';
import { Plus, X } from 'lucide-react';
import api from '../api/axios';
import { brl } from '../utils/format';
import { useAuth } from '../context/AuthContext';

const blank = { supplierId: '', ingredientId: '', price: 0, sku: '' };

export default function Products() {
  const { isAdmin, isSupplier } = useAuth();
  const canEdit = isAdmin || isSupplier;

  const [products, setProducts] = useState([]);
  const [suppliers, setSuppliers] = useState([]);
  const [ingredients, setIngredients] = useState([]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(blank);
  const [editingPrice, setEditingPrice] = useState({});

  const load = async () => {
    const [p, s, i] = await Promise.all([
      api.get('/products'),
      api.get('/suppliers'),
      api.get('/ingredients'),
    ]);
    setProducts(p.data);
    setSuppliers(s.data);
    setIngredients(i.data);
  };

  useEffect(() => { load(); }, []);

  const save = async (e) => {
    e.preventDefault();
    try {
      await api.post('/products', { ...form, price: Number(form.price) });
      toast.success('Produto cadastrado');
      setShowForm(false);
      setForm(blank);
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Erro');
    }
  };

  const updatePrice = async (id) => {
    const newPrice = editingPrice[id];
    if (newPrice === undefined) return;
    try {
      const { data } = await api.patch(`/products/${id}/price`, {
        price: Number(newPrice),
      });
      toast.success(
        `Preço atualizado · ${data.recalculatedRecipes} receita(s) recalculada(s)`,
      );
      setEditingPrice((p) => {
        const c = { ...p };
        delete c[id];
        return c;
      });
      load();
    } catch (err) {
      toast.error(err.response?.data?.message || 'Erro');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between flex-wrap gap-3">
        <div>
          <h1 className="text-2xl font-semibold">Produtos dos fornecedores</h1>
          <p className="text-sm text-ink-400">
            Atualizar preço aqui recalcula automaticamente todas as receitas que usam o ingrediente.
          </p>
        </div>
        {canEdit && (
          <button onClick={() => setShowForm(true)} className="btn-primary">
            <Plus size={16} /> Novo produto
          </button>
        )}
      </div>

      {showForm && (
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold">Novo produto</h3>
            <button onClick={() => setShowForm(false)} className="btn-ghost">
              <X size={14} />
            </button>
          </div>
          <form onSubmit={save} className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="md:col-span-2">
              <label className="label">Fornecedor *</label>
              <select className="input" value={form.supplierId}
                onChange={(e) => setForm({ ...form, supplierId: e.target.value })} required>
                <option value="">— Selecione —</option>
                {suppliers.map((s) => (
                  <option key={s.id} value={s.id}>{s.name}</option>
                ))}
              </select>
            </div>
            <div className="md:col-span-2">
              <label className="label">Ingrediente *</label>
              <select className="input" value={form.ingredientId}
                onChange={(e) => setForm({ ...form, ingredientId: e.target.value })} required>
                <option value="">— Selecione —</option>
                {ingredients.map((i) => (
                  <option key={i.id} value={i.id}>{i.name} ({i.unit})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="label">Preço por unidade (R$) *</label>
              <input type="number" step="0.0001" min="0" className="input"
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })} required />
            </div>
            <div>
              <label className="label">SKU (opcional)</label>
              <input className="input" value={form.sku}
                onChange={(e) => setForm({ ...form, sku: e.target.value })} />
            </div>
            <div className="md:col-span-4 flex justify-end">
              <button type="submit" className="btn-primary">Cadastrar</button>
            </div>
          </form>
        </div>
      )}

      <div className="card overflow-x-auto">
        {products.length === 0 ? (
          <p className="text-ink-400 text-center py-8">
            Nenhum produto de fornecedor cadastrado.
          </p>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-ink-400">
              <tr className="text-left border-b border-ink-700">
                <th className="py-2">Fornecedor</th>
                <th className="py-2">Ingrediente</th>
                <th className="py-2">SKU</th>
                <th className="py-2 text-right">Preço atual</th>
                {canEdit && <th className="py-2 text-right">Atualizar preço</th>}
              </tr>
            </thead>
            <tbody>
              {products.map((p) => (
                <tr key={p.id} className="border-b border-ink-700/50">
                  <td className="py-3">{p.supplier?.name}</td>
                  <td className="py-3">
                    {p.ingredient?.name}{' '}
                    <span className="text-ink-400">({p.ingredient?.unit})</span>
                  </td>
                  <td className="py-3 text-ink-400">{p.sku || '—'}</td>
                  <td className="py-3 text-right font-medium">{brl(p.price)}</td>
                  {canEdit && (
                    <td className="py-3 text-right">
                      <div className="inline-flex gap-2 items-center">
                        <input
                          type="number"
                          step="0.0001"
                          min="0"
                          placeholder={String(p.price)}
                          value={editingPrice[p.id] ?? ''}
                          onChange={(e) =>
                            setEditingPrice({
                              ...editingPrice,
                              [p.id]: e.target.value,
                            })
                          }
                          className="input w-28 text-right"
                        />
                        <button
                          onClick={() => updatePrice(p.id)}
                          className="btn-ghost"
                        >
                          Salvar
                        </button>
                      </div>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
