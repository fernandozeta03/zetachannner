export enum IngredientUnit {
  ML = 'ml',
  L = 'l',
  G = 'g',
  KG = 'kg',
  UNIT = 'unidade',
  DASH = 'dash',
}
