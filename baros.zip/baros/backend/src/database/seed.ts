import 'reflect-metadata';
import * as bcrypt from 'bcryptjs';
import dataSource from '../config/data-source';
import { User } from '../users/entities/user.entity';
import { UserRole } from '../common/enums/user-role.enum';
import { Ingredient } from '../ingredients/entities/ingredient.entity';
import { IngredientUnit } from '../common/enums/ingredient-unit.enum';
import { Recipe } from '../recipes/entities/recipe.entity';
import { RecipeIngredient } from '../recipes/entities/recipe-ingredient.entity';

async function seed() {
  await dataSource.initialize();
  console.log('🌱 Seed iniciado...');

  const userRepo = dataSource.getRepository(User);
  const ingRepo = dataSource.getRepository(Ingredient);
  const recipeRepo = dataSource.getRepository(Recipe);

  // ---- ADMIN
  const adminEmail = 'admin@baros.dev';
  let admin = await userRepo.findOne({ where: { email: adminEmail } });
  if (!admin) {
    admin = userRepo.create({
      name: 'Chefe de Bar',
      email: adminEmail,
      password: await bcrypt.hash('admin123', 10),
      role: UserRole.ADMIN,
      targetCmv: 25,
    });
    await userRepo.save(admin);
    console.log(`✓ Admin criado: ${adminEmail} / admin123`);
  }

  // ---- BARTENDER
  const bartenderEmail = 'bartender@baros.dev';
  if (!(await userRepo.findOne({ where: { email: bartenderEmail } }))) {
    await userRepo.save(
      userRepo.create({
        name: 'Bartender Demo',
        email: bartenderEmail,
        password: await bcrypt.hash('bartender123', 10),
        role: UserRole.BARTENDER,
      }),
    );
    console.log(`✓ Bartender criado: ${bartenderEmail} / bartender123`);
  }

  // ---- INGREDIENTES
  const seedIngredients = [
    { name: 'Gin', unit: IngredientUnit.ML, baseCost: 0.12 },
    { name: 'Campari', unit: IngredientUnit.ML, baseCost: 0.18 },
    { name: 'Vermute Tinto', unit: IngredientUnit.ML, baseCost: 0.10 },
    { name: 'Limão Tahiti', unit: IngredientUnit.UNIT, baseCost: 1.50 },
    { name: 'Açúcar', unit: IngredientUnit.G, baseCost: 0.005 },
    { name: 'Cachaça Premium', unit: IngredientUnit.ML, baseCost: 0.09 },
  ];

  const ingredients: Record<string, Ingredient> = {};
  for (const data of seedIngredients) {
    let ing = await ingRepo.findOne({ where: { name: data.name } });
    if (!ing) {
      ing = await ingRepo.save(ingRepo.create(data));
      console.log(`✓ Ingrediente: ${ing.name}`);
    }
    ingredients[ing.name] = ing;
  }

  // ---- RECEITA EXEMPLO: Negroni
  if (!(await recipeRepo.findOne({ where: { name: 'Negroni' } }))) {
    const items = [
      { ing: 'Gin', qty: 30 },
      { ing: 'Campari', qty: 30 },
      { ing: 'Vermute Tinto', qty: 30 },
    ];
    let totalCost = 0;
    const lines = items.map((it) => {
      const ingredient = ingredients[it.ing];
      const cost = it.qty * Number(ingredient.baseCost);
      totalCost += cost;
      return { ingredientId: ingredient.id, quantity: it.qty, cost };
    });
    const salePrice = 38;
    const cmv = Number(((totalCost / salePrice) * 100).toFixed(2));

    const recipe = recipeRepo.create({
      name: 'Negroni',
      category: 'Drink Clássico',
      preparation:
        'Adicione todos os ingredientes em um copo baixo com gelo, mexa por 20 segundos e finalize com a casca de laranja.',
      garnish: 'Casca de laranja',
      glassware: 'Old Fashioned',
      salePrice,
      totalCost: Number(totalCost.toFixed(4)),
      cmv,
      userId: admin.id,
      ingredients: lines.map((l) => {
        const ri = new RecipeIngredient();
        Object.assign(ri, l);
        return ri;
      }),
    });
    await recipeRepo.save(recipe);
    console.log(`✓ Receita exemplo criada: Negroni (CMV ${cmv}%)`);
  }

  await dataSource.destroy();
  console.log('🌱 Seed concluído!\n');
  console.log('Login admin:     admin@baros.dev / admin123');
  console.log('Login bartender: bartender@baros.dev / bartender123');
}

seed().catch((err) => {
  console.error('❌ Erro no seed:', err);
  process.exit(1);
});
