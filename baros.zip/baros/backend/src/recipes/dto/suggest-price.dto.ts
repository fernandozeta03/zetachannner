import { IsNumber, Min, Max } from 'class-validator';

export class SuggestPriceDto {
  /** CMV alvo em % (ex: 25 = 25%) */
  @IsNumber()
  @Min(1)
  @Max(99)
  targetCmv: number;
}
